# Market making and prediction papers

Two independent LaTeX projects, each with a compiled PDF, a table of contents,
author-year citations, and a BibTeX bibliography using plainnat.

The definitive trilogy DOIs supplied by the author are:

| Paper | Subject | DOI |
|---|---|---|
| 1 | Market impact and order execution | [10.5281/zenodo.22736805](https://doi.org/10.5281/zenodo.22736805) |
| 2 | Quoting and market making | [10.5281/zenodo.22759528](https://doi.org/10.5281/zenodo.22759528) |
| 3 | Forecasting and trading | [10.5281/zenodo.22759534](https://doi.org/10.5281/zenodo.22759534) |

The title pages and PDF subjects carry the corresponding paper's DOI.
Trilogy_Citations.bib provides the three citation records for reuse.

## Papers

- paper_2/p2_quoting.tex: Quoting Under a Misspecified Fill Law.
  Includes marked-wealth accounting, tagged queue positions, inventory
  reservations, cancellation and replacement, event-law derivative budgets,
  finite-book truncation, finite-state inventory control,
  shutdown thresholds, model-and-solver certificates, hybrid decision
  margins, discounted stationary certificates, an action-coverage
  impossibility result, two-quote statistical learning, and information
  ceilings for unbounded mark losses. Discrete-message value intervals
  yield an occupation-sensitive loss certificate in a 74-state queue
  model. Explicit lower bounds cover omitted tagged rank and calibration
  at a replacement boundary. The multi-lot extension retains batch
  consumption and partial fills during cancellation latency, with a sharp
  finite-stage approximation theorem and a cash-consistent marked example.
- paper_3/p3_forecast.tex: From Forecast to Position.
  Includes convex decision losses, mixed costs, marked price events,
  event timing, hidden-state filtering, exact and approximate book-state
  reduction, a combined observation-to-position certificate, sharp threshold rates, joint forecast-and-impact
  residuals, constrained adapted trading, causal OU tracking, and information
  loss decompositions. The extensions add a sharp curvature-diameter
  envelope, the sharp causal integration constant, and exact costs of
  misspecified persistence and friction. Further results give the exact
  scalar interval minimax position, sharp additive-forecast coefficients,
  and rational event-history-to-position enclosures. Price-specific
  state reduction can preserve every mean forecast without transition
  lumpability. Exact observation-value and delayed-feed identities
  separate hidden-state loss from implementation error.

These are the two companion papers to the established 117-page
Market_Impact_Execution_v14.pdf, "The Mathematics of Market Impact and
Order Execution." That first paper remains the execution foundation.
Trilogy_Contribution_Map.md records the division of contributions and the
specific connections reviewed. The short Certified Execution Cells attachment
is not used as a replacement for the established first paper.

Each paper folder is self-contained. Upload its contents into a separate
Overleaf project and select the corresponding .tex file as the main document.
Use pdfLaTeX with BibTeX. Locally, run latexmk -pdf followed by the main
filename from that paper's directory.

## Mathematical checks

The verification directory contains verify_theory.py, trilogy_extensions.py,
submitted_extensions.py, order_book_foundations.py, queue_certificates.py,
forecast_certificates.py, partial_fills_latency.py, observation_value.py,
requirements.txt, and the recorded
verification_results.json. Extension_Review.md records the corrections and
strengthenings made when integrating the six submitted extensions.

Install the dependencies in requirements.txt, then run:

    python verification/verify_theory.py

Forty-one groups check constrained gradient bounds, the shutdown threshold,
dynamic policy loss by independent forward and backward equations,
quadratic and mixed-cost optimization, Gaussian and smooth-threshold
formulas, generator-to-forecast bounds, causal HJB/Riccati identities,
finite information-bound examples, a global model-and-solver certificate,
hybrid margin sharpness, fixed-quote nonidentification, dependent-error MSE
rates, joint forecast-and-impact residuals, the causal adjoint, discounted
HJB and computed-value certificates, two-quote learning, unbounded-reward
information bounds, the sharp curvature-diameter envelope, filtered
forecast errors, persistence/friction misspecification, tagged-queue
absorption, replacement-clock control, event derivative enclosures,
finite-book exit coupling, additive prices, event-history filtering,
state and filter aggregation, and the complete observation-to-position bound.
Six further groups check the 74-state queue certificate, the exact
rank-information lower bound, the Poisson replacement-boundary rate,
sharp forecast coefficients, interval minimax positions, and exact
rational forecast-to-position enclosures.
Seven additional groups check multi-lot fill distributions, cancellation
values, sharp Erlang-stage error, nonlinear information decompositions,
price-specific state reduction, delayed-feed variance identities,
and an explicit latency/no-trade frontier.

The model-and-solver example computes its global HJB residual bound and
integrated certificate in exact rational arithmetic. ODE policy evaluation,
matrix optimization, and numerical integration provide separate comparisons.
The two-date information decomposition is also checked with exact fractions.
The two-quote expected losses are evaluated by floating-point Poisson
probability sums with explicit tail cutoffs, rather than Monte Carlo.
The curvature-diameter envelope has exact rational witnesses of equality.
The new event reward and its first two derivative-error budgets are enclosed
with exact polynomial coefficients over the complete action interval.
Order_Book_Revision.md records the microstructure assumptions, added results,
and independent comparisons used for the order-book foundation.
Sharpness_Revision.md describes the subsequent tighter certificates,
lower bounds, arithmetic details, and same-uncertainty-set comparisons.
Latency_and_Observation_Revision.md describes the partial-fill accounting,
finite-stage latency expansion, weaker price-specific state criterion,
and exact costs of hidden or delayed information.

The inputs are synthetic. These checks do not constitute empirical
calibration, a market-data backtest, a machine-checked proof, or a claim
of research priority. Mathematical hypotheses and scope are stated in
the papers.

The latest supplied DOI and proof-clarification corrections are documented in
[Reviewed_Corrections.md](Reviewed_Corrections.md); focused rerun results are
in verification/reviewed_fragment_checks.json.
