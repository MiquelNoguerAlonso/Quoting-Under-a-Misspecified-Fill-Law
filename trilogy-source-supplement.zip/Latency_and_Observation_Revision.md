# Partial fills, cancellation latency, and book information

This revision deepens Papers 2 and 3. The established execution paper is
preserved. The new examples remain synthetic and conditional on their
declared state, observation, and reward models.

## Paper 2

The matching map consumes ahead lots before executing the remaining
tagged quantity. It preserves q+m for bids and q-m for asks, including
partial fills of a pending-cancel order. A tilted finite generator gives
the executed-volume generating function. In the compound-Poisson
specialization, the first-fill probability has an explicit small-time
power determined by the minimum number of aggressive events needed
to reach the order. With three lots ahead and batches of one or three,
the leading coefficient is 2499/5000 times t^2.

The pending-cancel value is written with a finite generator Q, marked
reward rate r, post-acknowledgement value w, discount beta, and an
independent delay D. Writing A=Q-beta I and g=r+Aw gives
V^D-w=E integral_0^D exp(tA)g dt. The residual controls the effect of
immediate cancellation and perturbations in the delay distribution.

For a deterministic delay d approximated by k Erlang stages of mean d,
the uniform expected-value error is at most
min(G*d/sqrt(k), B*d^2/(2*k)), with G=||g|| and B=||Ag||.
The explicit leading bias is d^2 exp(dA)Ag/(2k); the remainder is bounded
by C*d^3*sqrt(3+6/k)/(6*k^(3/2)), C=||A^2g||.
A front-of-queue unit order with exponential execution gives a nonzero
1/k bias coefficient, establishing sharpness in a queue model.

The numerical cell has nine states, a two-lot bid initially behind
three external lots, and batch sizes one and three. Its quote remains
fixed at 99.98. The marking reference is 100, 99.99, or 99.84 according
to whether two, one, or zero tagged lots remain. Event rewards use the
complete cash-and-inventory change. A first one-lot fill contributes
0.01; the second contributes -0.29, including the revaluation of the
first lot. Direct two-lot execution contributes -0.28. No independent
average mark is multiplied by fill volume.

At delay 0.35, the initial pending value is -0.007228703685.
The probability of at least one fill is 0.047028950549 and expected
filled volume is 0.062815351599. The residual constants are exactly
G=303/500, B=3473/2500, and C=38763/12500. The uniform stage bound is
0.08508850/k; the initial scaled bias tends to -0.005219442028.
The general delay theorem assumes a common independent delay law.
Congestion-dependent delay needs a joint model rather than a
substitution of the marginal delay distribution.

## Paper 3

For v_h=integral_0^h exp(sQ)d ds, a partition preserves every
conditional-mean forecast exactly if and only if d,Qd,...,Q^(n-1)d
are constant on its cells. This finite criterion follows from
analyticity and Cayley-Hamilton. It does not imply transition
lumpability or preservation of other rewards.

The four-state witness has d=(0,0,1,-1) and Qd=-2d. Aggregating states
1 and 2 loses transition-law information because their rates to the
other cells differ. Yet all price means are exact. A valid three-state
forecast model has full intertwining residual norm 2 and price-specific
residual zero. The corresponding approximate certificate applies the
residual to exp(s*Qbar)*dbar before taking the norm.

For a common convex friction F and nested information classes G,H,
the oracle value gap equals
E[F*(E[Z|H])-F*(E[Z|G])] plus the Fenchel loss of the implemented
G-measurable position. The first term is nonnegative and measures
information unavailable to the trader. It can vanish despite hidden
state variation when all relevant means share one optimal action.
Quadratic friction gives the exact conditional-variance decomposition.

For a delayed state observation X_0 and current state X_delta, the
correct forecast is exp(delta Q)v at X_0. With quadratic friction,
the information loss is p[exp(delta Q)v^2-(exp(delta Q)v)^2]/(2a).
An exact jump-variance integral identifies its small-delay leading
term delta*p*Gamma_Q(v)/(2a). Using the unpropagated stale state adds
the separate squared bias p[exp(delta Q)v-v]^2/(2a), of order delta^2.
The oracle retains the old state and additionally observes the current
one, making the information classes genuinely nested.

At stationarity the information loss increases with delay for any
common convex friction. Observing the timestamp of an independently
random delay also has nonnegative value; using the mean delay in place
of the average transition semigroup is a further approximation.

A symmetric two-regime example has switch rate 20, compensators +/-2,
forecast horizon 0.05 seconds, curvature 0.7, and proportional cost
0.012. The correct stale-information position stops trading at
0.032042572444 seconds. This number describes the synthetic experiment,
not an empirically calibrated venue latency threshold.

## Verification and positioning

The complete supplement has 41 passing check groups. Seven new groups
include 32 partial-fill distribution comparisons, 128 generating-function
comparisons, 2,080 reservation cases, direct cancellation quadrature,
Erlang resolvent and gamma-density comparisons, 48 finite information
experiments, exact subspace identities, 36 nonreversible feed-delay
comparisons, and 12 timestamp experiments.

The final PDFs contain 37 pages for Paper 2 and 35 pages for Paper 3.
Both compile without LaTeX warnings or unresolved references. Every
rendered page has been visually inspected, with additional inspection
of the new theorems and numerical tables at full rendered resolution.

Exact rational arithmetic supplies the latency derivative constants
and the unperturbed subspace witness. Matrix exponentials, optimization,
and quadrature are numerical comparisons. Their success is not a
machine-checked proof or an independent originality review.

The new citations acknowledge established latency valuation and
value-of-information theory. The contributions here are the explicit
book-state matching, residual and approximation formulas, price-specific
compression criterion, and their connected loss comparisons.
