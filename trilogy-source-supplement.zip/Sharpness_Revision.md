# Sharper queue and forecast certificates

This revision strengthens Papers 2 and 3 and preserves the established
first paper. It adds analytical results, complete proofs, informative
finite-book examples, and reproducible numerical comparisons. All inputs
are synthetic; the uncertainty boxes are supplied assumptions.

## Paper 2

The discrete-message certificate first encloses every model-specific
optimal value by lower and upper uniformized Bellman iterations. It then
bounds the gap between each alternative message and the deployed one.
The external book Hamiltonian cancels from that comparison, as do
identical continuation destinations. A second monotone iteration bounds
the discounted occupation of those state-specific gaps. An upper
iterate remains a certificate under outward rounding, even if that
rounded iterate is not itself an exact supersolution.

The 74-state continuing model has observed flow regime, inventory in
[-2,2], one active unit quote at one of two levels on either side,
and tagged rank zero or one. Inventory reservations constrain message
maps. The regenerative external-lot convention, quote invalidation,
regime transitions, fill rewards, and replacement fees are all explicit
in the paper and code. Rate uncertainty has radius 0.0002 and nonzero
fill-reward uncertainty radius 0.00001. Message costs and maps are known.

| Quantity from inactive regime-zero, zero inventory | Value |
|---|---:|
| Center optimum | 0.077010515019 |
| Center loss from a policy omitting tagged rank | 0.000164165504 |
| Uniform gap bound | 0.069118529390 |
| Rational occupation-sensitive upper bound | 0.000169512560 |
| States with certified zero message gap | 62 of 74 |

The center and two interior models are evaluated independently by
policy iteration and linear solves. The family-wide certificate comes
from exact rational interval updates, not from testing those three
models. Both Bellman and occupation calculations use 320 iterations
with outward rounding to 12 decimal places.

The snapshot-information lower bound is exactly 697/15000, attained by
keeping with probability 34/75. It does not apply to a richer message
history that recovers rank. The calibration lower bound uses two nearby
Poisson laws and a total-variation testing argument; a plug-in rule
matches its tau^(-1/2) order. A local central limit calculation supplies
the explicit leading risk under shrinking displacement from the
replacement boundary. This experiment counts market orders reaching a
level, not tagged fills, and measures post-calibration decision loss.

## Paper 3

For a scalar forecast interval [l,u], the worst loss at a fixed feasible
position w is F(w)+max(F*(l)-lw,F*(u)-uw). With finite attained endpoint
optima, the exact minimax position is (F*(u)-F*(l))/(u-l). The proof
uses convexity and the ordering of endpoint optimal positions. It allows
nonsmooth costs, bounded positions, and no strong-curvature assumption.
The conjugate-secant rule is a scalar specialization of established
Bregman-center geometry, not a new general theory of centers.

Quadratic friction gives exact minimax loss (u-l)^2/(8a). A proportional
threshold interval [c-e,c+e] gives position 1/2 and loss e/2. A common
no-trade interval gives zero loss. A one-lot depletion model realizes
every forecast in an interior subinterval of (0,1), making both endpoint
lower bounds concrete in order-book terms. Separate two-state marked
models attain the posterior and drift coefficients of the additive
forecast bound and approach its generator coefficient.

The positive enclosure method uses componentwise Metzler exponential
bounds for the unnormalized event history. It uses stochastic
uniformization for the future additive price increment. The final
normalized forecast extrema reduce to sorted score cuts in a
positive-weight box. Outer boxes can discard correlations from a
common parameter; the minimax claim concerns the certified interval
and can be conservative for the original smaller model family.

| Four-state example, one common primitive box | Bound or position |
|---|---:|
| Forecast lower endpoint | 0.210697132332 |
| Forecast upper endpoint | 0.222819777337 |
| Norm-certificate loss at deployed position | 0.004036766177 |
| Interval loss at the same deployed position | 0.000078678533 |
| Rounded interval minimax position | 0.281083506906 |
| Loss upper bound at that rounded position | 0.000026242594 |

The norm comparison is recomputed for this same box. It is not compared
as if it used the narrower allowances from the preceding pairwise
example. The interval bound at the same position is more than 51 times
smaller; the changed position reduces the worst-case bound further.
No claim is made that realized profit improves by those factors.

The code encloses scalar exponentials with degree-44/45 Taylor bounds,
Metzler exponentials with degree-30 positive series and explicit norm
tails, and future increments with 25 uniformization terms (0 through 24).
The integrated tail is at most 3e-24 in the example. All enclosures and
reported decision bounds include rational outward rounding, including
rounding of the implemented minimax position.

## Verification and scope

At this revision stage, the complete supplement ran 34 check groups. The six new groups are
in queue_certificates.py and forecast_certificates.py. Independent
floating-point optimization and matrix exponentials check the relevant
formulas; exact fractions and proved remainder bounds produce the
family-wide certificates. A passing numerical check is not a
machine-checked proof or an independent peer review.

The new lower bounds establish sharpness for specific information
classes, uncertainty sets, and sampling experiments. They do not prove
that every global certificate in the trilogy is sharp, solve parameter
identification for a real exchange, or establish research priority.
The primary-source positioning explicitly credits robust dynamic
programming and Bregman-center theory.

This earlier revision produced 33-page and 30-page PDFs. The subsequent
partial-fill and latency revision is documented in
Latency_and_Observation_Revision.md; the package contains the latest PDFs.
