# Integration of the six submitted extensions

All six extensions from `extensions_p2_p3(1).tex` have been integrated into
the main LaTeX manuscripts. Placement notes and hard-coded theorem numbers
were replaced by the papers' own structure and cross-references.

| Extension | Integrated result and correction |
|---|---|
| Paper 2: discounting | The stationary discounted HJB, performance identity, primitive-error bound, and computed-value certificate are proved. In general the gradient bound includes a beta^-2 term, so the displayed quadratic regret bound can grow as epsilon^2 beta^-5. The beta^-3 form requires the leading transition contribution to vanish. The trivial reward-range bound is also available. |
| Paper 2: two logging quotes | Both logging quotes must belong to [0,D]. The concentration result measures revenue loss after calibration, excluding logging cost. The expected-loss expansion is justified, including the clipped estimator's rare events. The unconstrained spacing root 2.2177 is infeasible when kappa D <= 2 and delta0 >= 0; the largest permitted spacing minimizes the stated leading constant. Unknown parameters still require prior bounds or a separate confidence construction for sample-size planning. |
| Paper 2: unbounded information ceiling | Measurability, finite baseline value, integrability, and a uniform centered exponential-moment condition are explicit. The exponential payoff is per informed opportunity, with zero payoff when there is no fill. Its uniform moment envelope is sharpened to s/k-log(1+s/k), giving min(sqrt(2I),1)/k rather than 2sqrt(I)/k. It is not a per-realized-fill assertion. |
| Paper 3: curvature and diameter | The original minimum of two upper bounds remains valid. Combining their assumptions gives the sharper, attained envelope E^2/(2a) up to E=aW and WE-aW^2/2 beyond. This describes a uniform upper envelope, not the exact loss of every pair. Constraint indicators are zero inside and +infinity outside. |
| Paper 3: filtered forecast error | The projected causal-adjoint identity is retained. The sharp operator norm 2T/pi improves the horizon constant to 2T^2/(m pi^2). A sine error attains it for isotropic unconstrained cost; a constant bias does not. In the full adapted space the adjoint has no nonzero null vector. Restricted feasible directions can make errors decision-irrelevant through projection. |
| Paper 3: persistence and friction | Both stationary misspecification formulas are retained and proved. The asymmetry for equal under- and overestimation is stated exactly. Random-estimation approximations use MSE, including squared bias, with an independent stationary evaluation design and a controlled third-order remainder. |

These are refinements of conditional theory. The information argument is
positioned against the entropy variational principle and
[Russo and Zou (2016)](https://proceedings.mlr.press/v51/russo16.html),
and the discounted result does not claim to replace the ergodic analysis
already cited in Paper 2.

## Verification

Twenty check groups pass. The six added groups cover:

1. Discounted performance identities, value perturbations, and computed
   certificates against independent policy evaluation and matrix integrals.
2. Two-quote concentration, finite-sample Poisson probability sums, the
   expected-loss coefficient, and the feasible spacing restriction.
3. Exponential-moment formulas against quadrature and a nontrivial binary
   signal's value against the information ceiling.
4. The curvature-diameter envelope in 192 scalar optimization cases and
   exact rational equality examples on both branches.
5. The causal integral's norm, a sharp error profile, and an error annihilated
   by projection onto a restricted feasible class.
6. Persistence and friction formulas against 96 independent stationary
   Lyapunov calculations, including a biased-estimator example.

The recorded results distinguish exact rational identities from numerical
verification. They are not market-data backtests or machine-checked proofs.
