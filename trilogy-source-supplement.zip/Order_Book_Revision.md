# Order-book foundations added to Papers 2 and 3

Paper 1 remains the established execution monograph. The revisions below
make the book model and information assumptions explicit in its two companions.

| Paper | Added mechanism | Role in the certificate |
|---|---|---|
| 2, Section 3 | Tagged queue rank and competing execution times | Distinguishes queue absorption from a constant Poisson fill law |
| 2, Section 3 | Inventory reservations and pending messages | Keeps live executable orders consistent with hard inventory bounds |
| 2, Section 3 | Replacement at finite-rate opportunities | Prices loss of priority and replacement fees through continuation value |
| 2, Section 3 | Event-rate and conditional-mark derivative budgets | Supplies the reward, gradient, and curvature bounds used by later control results |
| 2, Section 3 | Coupling until exit from a finite cell | Adds an explicit truncation allowance, conditional on a policy-uniform exit bound |
| 3, Section 5 | Additive price marks and event timing | Forecasts clock-time price changes without confining price to a finite grid |
| 3, Section 5 | Event-history filtering, including silence | Supplies a posterior and a pathwise perturbation allowance |
| 3, Section 5 | Exact and approximate state reduction | Separates rate aggregation from price-compensator compatibility |
| 3, Section 5 | Observation-compatible filter reduction | States the stronger conditions needed to run the filter on coarse states |
| 3, Section 5 | Complete observation-to-position bound | Combines inference, parameter, reduction, price-drift, and optimizer errors |

The queue matching cell uses unit lots and strict price-time priority at
a level. Market orders must reach that level before affecting the tagged
order. An accepted atomic replacement is one declared message convention;
separate cancellation and insertion delays need pending states. Deterministic
delays generally require an age variable. Smooth offset certificates do not
turn a discrete tick grid into a differentiable action set.

In Paper 3, the book law used for forecasting is exogenous to the selected
position. A positive span-contraction rate is an additional property; zero
is always permitted. A rare event history can make the posterior bound
uninformative. Aggregating the latent transition generator alone does not
justify aggregating the observation filter or discarding price marks.

The mathematical ingredients include established queue absorption,
point-process filtering, Markov lumpability, and convex duality. Their
composition here makes the downstream loss and its assumptions explicit;
the papers do not claim invention of those classical methods.

## Verification

All 28 groups in verification/verify_theory.py pass. The eight new groups
are in verification/order_book_foundations.py. The full results, tolerances,
parameters, and environment versions are included with the source package.

- Queue products agree with independent resolvents within 3e-16;
  24 additional comparisons recover the Erlang fill probabilities.
- A six-state replacement model gives optimal initial value 0.35606137.
  Always replacing loses 0.17792893; its independent occupation integral
  agrees within 5e-11.
- The event reward and its first two derivative-error budgets are globally
  enclosed using exact rational polynomial coefficients on [0, 1].
- Six finite-cap examples compare Poisson exit probabilities with Gamma
  first-exit-time integrals.
- Additive price forecasts agree with independently integrated state
  probabilities; a one-state negative control preserves the generator but
  changes the forecast by changing the event clock.
- The event-history filter agrees with its normalized nonlinear ODE within
  2e-14. Silence changes the fast-regime probability from 0.5 to 0.119203
  in the stated two-regime example.
- Exact state and filter aggregation are checked separately. A perturbed
  non-lumpable model is compared with its Duhamel residual integral.
- The four-state, two-cell worked example has actual position loss
  0.00002020 and certified upper bound 0.00308877, including an inexact
  position optimizer. The bound is conservative and conditional on the
  supplied model-error allowances.

These are reproducible synthetic mathematical checks, not empirical
calibration, profitability evidence, or machine-checked proofs.
