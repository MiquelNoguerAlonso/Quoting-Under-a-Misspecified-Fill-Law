# The trilogy: contribution and evidence

The established first paper is **The Mathematics of Market Impact and
Order Execution: Impact Kernels, Feasible Policies, and Execution
Certificates**, Market_Impact_Execution_v14.pdf, 117 pages,
[DOI 10.5281/zenodo.22736805](https://doi.org/10.5281/zenodo.22736805).
The short Certified Execution Cells attachment is a separate text.

The definitive DOI for Paper 2 is
[10.5281/zenodo.22759528](https://doi.org/10.5281/zenodo.22759528);
the definitive DOI for Paper 3 is
[10.5281/zenodo.22759534](https://doi.org/10.5281/zenodo.22759534).

This revision develops Papers 2 and 3. The comparison with Paper 1 checks
its introduction, the execution certificates in Section 17, and the
observation and action certificates in Sections 29.8–29.9. It is not a
new proof-by-proof audit of the entire 117-page manuscript.

| Paper | Decision and benchmark | Main connection |
|---|---|---|
| 1. Market impact and execution | Complete a parent mandate with feasible instructions under a stated observation class | Conserved execution ledger; kernel, model, policy-class, optimization, and observation errors |
| 2. Quoting under a misspecified fill law | Provide liquidity while controlling inventory; compare with a finite-horizon or stationary discounted optimum | Marked wealth accounting; smooth quote residuals; solver and curvature enclosures; hybrid action margins; two-quote coverage |
| 3. From forecast to position | Choose and trade a predictive position under costs and available information | Decision-dependent forecast metrics; joint forecast-and-impact residuals; causal and information-class losses |

The common principle is to measure errors in the units of the downstream
decision. The papers use different objectives and feasible sets; their
individual regret bounds are not automatically additive across an integrated
trading desk.

## Substantive additions to Paper 2

1. A computed-value certificate includes the HJB residual, terminal
   discrepancy, primitive-model uncertainty, a normal-cone optimization
   residual, and a Hessian enclosure. Its final uniform bound contains
   neither the unknown true value function nor the true occupation law.
2. Hybrid actions have a smooth contribution of order error squared and
   a switching contribution governed by the true deployed occupation margin.
   An explicit two-action construction attains the margin exponent.
3. Two exponential fill laws generate identical logs at a single fixed
   quote while their optimal quotes differ. A positive regret lower bound
   persists for every sample size under that logging design.
4. The computed-value example encloses the complete time interval using
   rational polynomial calculations. Its bound is approximately 0.001136665;
   independently evaluated regret is approximately 0.000365316.
5. Stationary discounting gives a horizon-free comparison and a computed
   residual certificate. The general curvature term can grow as beta^-5;
   this does not establish an ergodic limit or a matching regret lower bound.
6. Two feasible logging quotes identify an exponential cell with unknown
   intensity scale. Concentration gives a deployed revenue-loss bound of
   order log(1/epsilon)/tau, and a proved expected-loss expansion gives
   its leading constant. Logging cost is a separate criterion.
7. A centered exponential-moment hypothesis permits unbounded rewards
   in the information ceiling. The exponential mark example yields
   min(sqrt(2I), 1)/k per informed opportunity.

Second-order market-making sensitivity is already established in
[Cao et al., Logarithmic regret in the ergodic Avellaneda–Stoikov model](https://arxiv.org/abs/2409.02025),
published in SIAM Journal on Financial Mathematics in 2026. Paper 2
does not claim priority for that phenomenon or a better online learning
rate. Its stated scope is finite-horizon and discounted marked models,
numerical residual accounting, hybrid decisions, and specified coverage
experiments. The explicit queue construction connects these certificates
to tagged-order priority, inventory reservations, and costly replacement.
Event-rate and conditional-mark errors feed the primitive budgets; a
coupling allowance handles departure from a finite retained cell.
Model uncertainty also predates this paper:
[Cartea, Donnelly, and Jaimungal (2017)](https://doi.org/10.1137/16M106282X).

## Substantive additions to Paper 3

1. Under a threshold margin exponent alpha, uniformly bounded error e
   gives a loss bound of order e^(alpha+1). With only an MSE budget,
   the best uniform exponent is (alpha+1)/(alpha+2). A fixed signal
   distribution with dependent errors proves sharpness.
2. An adapted Hilbert-space theorem combines forecast, impact, and
   optimization residuals before squaring. It includes common convex
   constraints and proportional turnover charges.
3. On affine feasible classes, the certificate becomes an exact compressed
   inverse-energy identity. It characterizes errors that leave the optimal
   decision unchanged.
4. Nested affine information classes split total loss into an information
   energy and an implementation energy. The exact example is
   13/50 = 1/4 + 1/100.
5. The causal adjoint of accumulated inventory uses a conditional future
   integral. A finite observation tree checks it independently of the
   continuous-time proof.
6. Combining strong curvature a with domain diameter W gives the sharp
   envelope E^2/(2a) for E <= aW and WE-aW^2/2 above it. A constrained
   scalar quadratic attains both branches.
7. The forecast-only affine loss is the inverse-energy of the projected
   causal forecast integral. The integration norm is exactly 2T/pi;
   constant bias is not its worst case at fixed L2 norm.
8. Exact stationary formulas price misspecified mean reversion and friction.
   A local expected-cost approximation uses estimation MSE, including bias,
   under a stated independent evaluation design.

9. An additive price law preserves price marks and the event clock even
   when the relative-book state is unchanged. A pathwise event filter uses
   both arrivals and silence, with a likelihood-dependent error bound.
10. State reduction has a rate-intertwining residual and a separate
    price-compensator residual. Reducing the filter itself requires stronger
    compatibility with each observed event type and the survival law.
11. A complete certificate combines filtering, parameter uncertainty,
    state reduction, price marks, and optimization residuals before applying
    the curvature-diameter loss envelope. A reproducible four-state example
    reduces to two forecast cells and evaluates the resulting position loss.

These use established convex duality and Hilbert projection theory.
The margin mechanism is related to
[Audibert and Tsybakov (2007)](https://arxiv.org/abs/0708.2321).
Signal-adaptive execution with temporary and transient impact is already
developed by [Neuman and Voss](https://arxiv.org/abs/2002.09549).
The paper's joint error accounting does not replace their solution theory
or the strategic equilibrium studied by
[Cont, Micheli, and Neuman (2025)](https://doi.org/10.1007/s00780-025-00560-w).

## Sharper certificates and limits

Paper 2 now treats finite quote messages directly. A robust value
enclosure brackets every model-specific optimum in a declared event-law
family. The common external Hamiltonian cancels from message comparisons;
equal post-message destinations cancel exactly as well. A second
positive iteration propagates the resulting state-specific action gaps
through the deployed policy. No action derivatives, curvature modulus,
or true occupation law are needed. The 74-state example includes
inventory caps, one active tagged order, queue progress, regime changes,
replacement fees, and uncertainty in rates and fill marks. Its loss
upper bound is 0.000169512560, while the center-model loss is
0.000164165504. The uniform gap bound is 0.06911853.

Two queue lower bounds complement this positive result. Identical
displayed snapshots with different tagged rank produce an exact
randomized minimax loss of 697/15000, even with known primitives.
With rank observed, a market-order Poisson calibration experiment
has matching minimax order tau^(-1/2) near a keep/replace boundary,
including an explicit local risk limit. The latter is a single
post-calibration decision, not cumulative online regret.

Paper 3 now solves the scalar interval decision exactly: the minimax
position is the secant slope of the friction conjugate between the
forecast endpoints. This remains valid without strong curvature when
the endpoint optima are attained. It gives matching quadratic and
proportional-threshold minimax radii; a queue-depletion model realizes
every endpoint mean. Two-state marked-event models establish that the
additive forecast's h, A_omega(h), and C_omega(h) coefficients are
individually best possible.

Positive event-history and future-price enclosures retain information
discarded by repeated norm bounds. In the four-state example, the
certified forecast interval is [0.210697132332, 0.222819777337].
Under exactly the same primitive box and deployed position, the norm
loss bound is 0.004036766177 and the interval loss bound is
0.000078678533. The rounded interval minimax position 0.281083506906
has certified loss at most 0.000026242594. These are worst-case bounds
over stated enclosures, not empirical performance improvements.

Robust Bellman methods and Bregman centers are established ideas:
[Iyengar (2005)](https://doi.org/10.1287/moor.1040.0129) and
[Bauschke et al. (2010)](https://doi.org/10.1016/j.jat.2010.01.001)
are now cited. The papers make the queue-message cancellation,
information limits, scalar decision formulas, and marked-event
enclosures explicit. No priority claim is made for the underlying
general mathematical methods.

## Partial fills, latency, and observation value

Paper 2 now tracks multi-lot partial fills explicitly. The matching map
preserves the live inventory reservation; the fill transform retains
the complete executed-volume distribution and its price marks. A
pending cancellation has an exact value-residual identity and a
Wasserstein bound for independent delay laws. A deterministic delay
approximated by k mean-matched Erlang stages has expected-value error
of order 1/k, with an explicit leading coefficient and an O(k^-3/2)
remainder. A tagged one-unit queue proves that the 1/k order is sharp.
The nine-state example uses a fixed quote, state-dependent marking
reference, and full revaluation of previously filled inventory.

Paper 3 now characterizes price-mean sufficiency by the finite subspace
generated by d,Qd,...,Q^(n-1)d. This is weaker than preserving every
transition probability. A nonlumpable four-state model has exactly
preserved price means at every horizon, despite a full rate-residual
norm of 2. The new price-specific residual vanishes in that example.

For general convex friction, the full-information value gap splits
exactly into a conditional Jensen gap and the trader's implementation
loss. A delayed feed gives an exact Markov jump-variance integral.
Its information loss is generally first order in a small delay, while
the additional bias from failing to propagate the stale state is
second order under quadratic friction. Stationary latency frontiers,
timestamp value, and a mixed-cost no-trade delay are explicit.

These results use established Markov reward methods, finite-dimensional
linear algebra, and the value-of-information principle. The papers
credit [Lehalle and Mounjid (2017)](https://doi.org/10.1142/S2382626617500095),
[Moallemi and Saglam (2013)](https://doi.org/10.1287/opre.2013.1165),
and [Blackwell (1953)](https://doi.org/10.1214/aoms/1177729032).
They do not claim to originate latency valuation or comparison of
information structures.

## Verification and assessment

All 41 verification groups pass. The supplement distinguishes exact
rational checks from numerical checks. The complete computed HJB
residual and its integrated upper bound are rational enclosures in the
specified example; general model uncertainty bounds remain assumptions.
The new groups use discounted matrix-exponential comparisons, Poisson
probability sums, moment-generating-function quadrature, 192 scalar
optimizations, integration singular values, and 96 Lyapunov calculations.
Eight additional groups compare queue products with absorption resolvents,
replacement HJB values with forward policy evaluation, event error budgets
with exact polynomial expansions, truncation bounds with first-exit
integrals, additive forecasts with probability-flow ODEs, filtering with
normalized ODEs, and state reduction with matrix-exponential identities.
The complete observation-to-position group combines these transfers.
The six subsequent groups add exact rational queue value intervals and
occupation bounds, rank-information loss, Poisson boundary risk,
additive-forecast sharpness, interval minimax decisions, and positive
likelihood/future-increment enclosures. The seven newest groups add
partial-fill transforms, live cancellation values, Erlang-stage
approximations, nonlinear information loss, price-specific features,
feed-delay variance, and the two-state latency frontier.
There are no fitted market data or out-of-sample profitability claims.

The revision strengthens the proofs, connects the papers, identifies
sharp failure boundaries, and positions the claims against directly
relevant literature. Numerical success does not establish research
priority or publication significance. An A+ assessment of the whole
trilogy would additionally require an independent originality and
proof review of the complete first paper together with these companions.
